Certificates procured by the WSF Team from various sources.

Discord - https://wsfteam.xyz/discord
GitHub: https://github.com/WhySooooFurious
X - https://x.com/wsf_team
Ko-Fi - ko-fi.com/anmol56

Cert Password:

WSF